/*
    NAMES: CYRUS DIEGO and DANIEL ROJAS-CARDONA
    ID: 1528911 and 1531475
    CMPUT 275 WINTER 2019 Final Project: FFT Visualizer

    main.cpp : inits application and calls run method
*/
#include "globals.h"
#include "application.h"

int main() {
    application FFT("Music Visualizer");
    FFT.run();
    return 0;
}
